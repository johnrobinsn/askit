repackage with 

```
python setup.py sdist bdist_wheel
```