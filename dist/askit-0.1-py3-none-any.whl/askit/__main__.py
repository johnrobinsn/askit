from .main import main  # Adjust based on your actual module structure

if __name__ == "__main__":
    main()